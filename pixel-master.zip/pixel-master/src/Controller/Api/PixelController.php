<?php

namespace App\Controller\Api;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\Pixel;
use App\Form\PixelType;
use App\Form\PixelApiType;


class PixelController extends AbstractPixelApiController
{


    /**
     * @Route("/api/v1/pixel/{domain}", methods={"GET"})
     */
    public function getPixel(Request $request): Response
    {
        $domain = $request->get('domain');
        $pixel = $this->getDoctrine()->getRepository(Pixel::class)->findOneBy(['domain' => $domain]);
        if(!$pixel) throw new NotFoundHttpException();
        return $this->respond($pixel);
    }


    /**
     * @Route("/api/v1/pixel/all/{domain}", methods={"GET"})
     */
    public function getPixels(Request $request): Response
    {
        $domain = $request->get('domain');
        $pixel = $this->getDoctrine()->getRepository(Pixel::class)->findBy(['domain' => $domain]);
        return $this->respond($pixel);
    }



    //    /**
//     * @Route("/api/v1/pixel", name="pixel_all_api", methods={"GET"} )
//     */
//    public function pixelListApi(Request $request): Response
//    {
//        $pixel = $this->getDoctrine()->getRepository(Pixel::class)->findAll();
//        return $this->respond($pixel);
//    }

    //    /**
//     * @Route("/api/v1/pixel/{domain}", name="pixel_all_api", methods={"GET"} )
//     */
//    public function pixelListApi(Request $request): Response
//    {
//        $domain = $request->get('domain');
//        $pixel = $this->getDoctrine()->getRepository(Pixel::class)->findBy(['domain' => $domain]);
//        $pixel = $this->getDoctrine()->getRepository(Pixel::class)->findAll();
//        return $this->respond($pixel);
//    }

//    /**
//     * @Route("/api/v1/pixel", name="pixel_create_api", methods={"POST"} )
//     */
//    public function pixelCreateApi(Request $request): Response
//    {
//
//        $form = $this->buildForm(PixelApiType::class);
//
//        $form->handleRequest($request);
//
//        if(!$form->isSubmitted() || !$form->isValid()) {
//            return $this->respond($form, Response::HTTP_BAD_REQUEST);
//        }
//
//        /** @var  Pixel $customer */
//        $customer = $form->getData();
//
//        $em = $this->getDoctrine()->getManager();
//        $em->persist($customer);
//        $em->flush();
//
//        return $this->respond($customer);
//    }



    // PATCH - лише ті поля які хочемо оновити
    // PUT - всі поля треба відпраити

//    /**
//     * @Route("/api/v1/pixel/{domain}", name="pixel_update_api", methods={"PATCH"} )
//     */
//    public function pixelUpdateApi(Request $request): Response
//    {
//
//        $domain = $request->get('domain');
//
//        $pixel = $this->getDoctrine()->getRepository(Pixel::class)->findOneBy([
//            'domain' => $domain
//        ]);
//
//        if(!$pixel) throw new NotFoundHttpException();
//
//        $form = $this->buildForm(PixelApiType::class, $pixel, [
//            'method' => $request->getMethod(),
//        ]);
//
//        $form->handleRequest($request);
//
//        if(!$form->isSubmitted() || !$form->isValid()) {
//            return $this->respond($form, Response::HTTP_BAD_REQUEST);
//        }
//
//        /** @var  Pixel $customer */
//        $customer = $form->getData();
//
//        $em = $this->getDoctrine()->getManager();
//        $em->persist($customer);
//        $em->flush();
//
//        return $this->respond($customer);
//    }


//    /**
//     * @Route("/api/v1/pixel/{domain}", name="pixel_delete_api", methods={"DELETE"} )
//     */
//    public function pixelDeleteApi(Request $request): Response
//    {
//        $domain = $request->get('domain');
//
//        $pixel = $this->getDoctrine()->getRepository(Pixel::class)->findOneBy([
//            'domain' => $domain
//        ]);
//
//        if(!$pixel) throw new NotFoundHttpException();
//
//        $em = $this->getDoctrine()->getManager();
//        $em->remove($pixel);
//        $em->flush();
//
//        return $this->respond('');
//    }


}
