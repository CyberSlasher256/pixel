<?php

namespace App\Controller\Api;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\PixelLogs;


class PixelLogsController extends AbstractPixelApiController
{


    /**
     * @Route("/api/v1/pixel/logs", methods={"POST"} )
     */
    public function pixelLogsCreateApi(Request $request): Response
    {
        $content = json_decode($request->getContent(),true);

        $domain = $content['domain'];
        $user_id_in_crm = $content['user_id_in_crm'];
        $http_user_agent = $content['http_user_agent'];
        $user_ip = $content['user_ip'];
        $page_type = $content['page_type'];
        $mpc_4 = $content['mpc_4'];

        $new_log = new PixelLogs();
        $new_log->setDomain((string)$domain);
        $new_log->setUserIdInCrm((string)$user_id_in_crm);
        $new_log->setUserIp((string)$user_ip);
        $new_log->setMpc4((string)$mpc_4);
        $new_log->setHttpUserAgent((string)$http_user_agent);
        $new_log->setPageType((string)$page_type);

        $em = $this->getDoctrine()->getManager();
        $em->persist($new_log);
        $em->flush();

        return $this->respond($user_ip);
    }



}
