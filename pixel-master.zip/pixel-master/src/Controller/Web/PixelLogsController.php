<?php

namespace App\Controller\Web;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\PixelLogs;


/**
 * @Route("/a2j4NB7K9i")
 */
class PixelLogsController extends AbstractController
{

    /**
     * @Route("/admin/pixel/logs/list", name="pixel_logs_list")
     */
    public function pixelLogsList(Request $request, PaginatorInterface $paginator): Response
    {

        if (isset($_GET['search'])) $word = $_GET['search'];
        else $word = '';

        if (isset($_GET['perpage'])) $perpage = $_GET['perpage'];
        else $perpage = 32;

        if (isset($_GET['page'])) $page = $_GET['page'];
        else $page = 1;

        $query = $this->getDoctrine()->getRepository(PixelLogs::class)->searchPixelLogsAll($word);
        $pixel_logs_list = $paginator->paginate(
            $query,
            $page,
            $request->query->getInt('limit', $perpage));

        return $this->render('admin/pixel_logs_list.html.twig', [
            'pixel_logs_list' => $pixel_logs_list,
            'word' => $word,
            'perpage' => $perpage,
        ]);
    }


    /**
    * @Route("/admin/pixel/logs/all/delete", name="pixel_logs_delete_all")
    */
    public function pixelLogsDeleteAll()
    {
        $dql = "DELETE FROM App:PixelLogs";
        $em = $this->getDoctrine()->getManager();
        $em->createQuery($dql)->getResult();
        return $this->redirectToRoute('pixel_logs_list');
    }


}