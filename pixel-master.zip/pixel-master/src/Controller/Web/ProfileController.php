<?php

namespace App\Controller\Web;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;



/**
 * @Route("/aj6Y6Zg8J3")
 */
class ProfileController extends AbstractController
{


    /**
     * @Route("/admin", name="admin_profile")
     */
    public function profile(): Response
    {

        $pixel = $this->getDoctrine()->getRepository('App:Pixel')->findAll();
        $pixel_count = count($pixel);

        return $this->render('admin/profile.html.twig',['pixel_count'=>$pixel_count]);
    }


//    /**
//     * @Route("/documentation", name="admin_documentation")
//     */
//    public function documentation(): Response
//    {
//        return $this->render('admin/documentation.html.twig');
//    }


}
