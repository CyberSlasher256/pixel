<?php

namespace App\Controller\Web;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\Pixel;
use App\Form\PixelType;


/**
 * @Route("/4m9Ff2JsM3")
 */
class PixelController extends AbstractController
{

    /**
     * @Route("/admin/pixel/list", name="pixel_list")
     */
    public function pixelList(Request $request, PaginatorInterface $paginator): Response
    {

        if(isset($_GET['search'])) $word = $_GET['search'];
        else $word = '';

        if(isset($_GET['perpage'])) $perpage = $_GET['perpage'];
        else $perpage = 32;

        if(isset($_GET['page'])) $page = $_GET['page'];
        else $page = 1;

        $pixel = new Pixel();

        $form = $this->createForm(PixelType::class, $pixel);
        $form->handleRequest($request);

        $query = $this->getDoctrine()->getRepository(Pixel::class)->searchPixelAll($word);
        $pixel_list = $paginator->paginate(
            $query,
            $page,
            $request->query->getInt('limit', $perpage));

        if ($form->isSubmitted() && $form->isValid()) {

//            $domain_with_form = $request->request->get('pixel')['domain'];
//            $result = $this->getDoctrine()->getManager()->getRepository(Pixel::class)->findOneBy(['domain'=>$domain_with_form]);
//
//            if(!isset($result)) {
                $em = $this->getDoctrine()->getManager();
                $em->persist($pixel);
                $em->flush();
          //  }
//            else $this->addFlash("error", "already exists");

            return $this->redirectToRoute('pixel_list');
        }

        return $this->render('admin/pixel_list.html.twig', [
            'pixel_list' => $pixel_list,
            'word' => $word,
            'perpage' => $perpage,
            'form' => $form->createView()
        ]);

    }


    /**
     * @Route("/admin/pixel/edit/{pixel_id}", name="pixel_edit", requirements={"pixel_id"="\d+"})
     */
    public function pixelEdit(Request $request, $pixel_id): Response
    {
        $pixel_edit = $this->getDoctrine()->getManager()->getRepository(Pixel::class)->find($pixel_id);

        $form = $this->createForm(PixelType::class, $pixel_edit);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

//            $domain_with_form = $request->request->get('pixel')['domain'];
//            $old_domain = $request->request->get('old_domain');
//
//            if($domain_with_form != $old_domain) {
//                $result = $this->getDoctrine()->getManager()->getRepository(Pixel::class)->findOneBy(['domain' => $domain_with_form]);
//                if(!isset($result)) {
                    $em = $this->getDoctrine()->getManager();
                    $em->persist($pixel_edit);
                    $em->flush();
//                }
//                else $this->addFlash("error", "already exists");
//            }

            return $this->redirectToRoute('pixel_list');
        }

        return $this->render('admin/pixel_edit.html.twig', [
            'form' => $form->createView(),
            'old_domain' => $pixel_edit->getDomain()
        ]);

    }

    /**
     * @Route("/admin/pixel/delete/{pixel_id}", name="pixel_delete", requirements={"pixel_id"="\d+"})
     */
    public function pixelDelete($pixel_id): Response
    {
        $mailing = $this->getDoctrine()->getManager()->getRepository(Pixel::class)->find($pixel_id);
        $em = $this->getDoctrine()->getManager();
        $em->remove($mailing);
        $em->flush();

        return $this->redirectToRoute('pixel_list');
    }

    /**
     * @Route("/admin/pixel/delete/many/{params}", name="pixel_delete_all_many")
     */
    public function pixelDeleteMany($params)
    {
        $params = explode("&", $params);
        unset($params[count($params)-1]);
        foreach ($params as $key=>$param) {
            $pixel_id = (integer) $param;
            $pixel = $this->getDoctrine()->getRepository(Pixel::class)->find($pixel_id);
            if($pixel){
                $em = $this->getDoctrine()->getManager();
                $em->remove($pixel);
                $em->flush();
            }
        }
        return $this->redirectToRoute('pixel_list');
    }


//    /**
//     * @Route("/admin/pixel/delete/all", name="pixel_delete_all")
//     */
//    public function pixelDeleteAll()
//    {
//        $dql = "DELETE FROM App:Pixel";
//        $em = $this->getDoctrine()->getManager();
//        $em->createQuery($dql)->getResult();
//        return $this->redirectToRoute('pixel_list');
//    }




}
