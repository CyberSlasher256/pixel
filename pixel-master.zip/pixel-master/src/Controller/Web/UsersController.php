<?php

namespace App\Controller\Web;

use Knp\Component\Pager\PaginatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use App\Entity\User;
use App\Form\UserType;



/**
 * @Route("/AXh4jDc584")
 */
class UsersController extends AbstractController
{

//    /**
//     * @var UserPasswordEncoderInterface
//     */
//    private UserPasswordEncoderInterface $passwordEncoder;
//
//    /**
//     * UserFixture constructor.
//     * @param UserPasswordEncoderInterface $passwordEncoder
//     */
//    public function __construct(UserPasswordEncoderInterface $passwordEncoder)
//    {
//        $this->passwordEncoder = $passwordEncoder;
//    }
//
//    /**
//     * @Route("/admin/user/create", name="user_create")
//     */
//    public function userCreate(Request $request, PaginatorInterface $paginator): Response
//    {
//
//        $user = new User();
//
//        $form = $this->createForm(UserType::class, $user);
//        $form->handleRequest($request);
//
//        if ($form->isSubmitted() && $form->isValid()) {
//            $user->setRoles(["ROLE_ADMIN"]);
//            $user->setIsVerified(true);
//            $user->setPassword($this->passwordEncoder->encodePassword(
//                $user,
//                $user->getPassword()
//            ));
//
//            $em = $this->getDoctrine()->getManager();
//            $em->persist($user);
//            $em->flush();
//            return $this->redirectToRoute('user_list');
//        }
//
//        return $this->render('admin/user_edit.html.twig', [
//            'form' => $form->createView()
//        ]);
//
//    }


    /**
     * @Route("/admin/user/list", name="user_list")
     */
    public function userList(Request $request, PaginatorInterface $paginator): Response
    {

        if(isset($_GET['search'])) $word = $_GET['search'];
        else $word = '';

        if(isset($_GET['perpage'])) $perpage = $_GET['perpage'];
        else $perpage = 32;

        if(isset($_GET['page'])) $page = $_GET['page'];
        else $page = 1;

        $query = $this->getDoctrine()->getRepository(User::class)->searchUserAll($word);
        $users_list = $paginator->paginate(
            $query,
            $page,
            $request->query->getInt('limit', $perpage));

        return $this->render('admin/user_list.html.twig', [
            'users_list' => $users_list,
            'word' => $word,
            'perpage' => $perpage,
        ]);

    }





}
