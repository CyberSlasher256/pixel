<?php

namespace App\Traits;

/**
 * Trait QueryUtilityTrait
 * @package App\Traits
 */
trait QueryUtilityTrait
{
    /**
     * @param $url
     * @return array
     */
    public function getQueryParams($url)
    {
        $params = [];
        $urlComponents = parse_url($url);
        if (\array_key_exists('query', $urlComponents)) {
            parse_str(($urlComponents['query'] ?? ''), $params);
        }

        return $params;
    }

}
