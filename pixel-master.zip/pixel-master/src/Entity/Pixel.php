<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Security\Core\User\UserInterface;
use DateTimeInterface;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

/**
 * @ORM\Entity(repositoryClass="App\Repository\PixelRepository")
 * @ORM\Table(name="pixel")
 * @ORM\HasLifecycleCallbacks
 */
class Pixel
{

    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=200)
     */
    private $domain;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $registration_event;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $viewing_event;

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $pixel_id;

    /**
     * @ORM\Column(type="string", length=200)
     */
    private $type_of_service;

    /**
     * @ORM\Column(type="datetime")
     */
    protected $created_at;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    protected $updated_at;

    /**
     * @ORM\PrePersist
     */
    public function onPrePersist()
    {
        $this->created_at = new \DateTime("now");
    }

    /**
     * @ORM\PreUpdate
     */
    public function onPreUpdate()
    {
        $this->updated_at = new \DateTime("now");
    }

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @param string $domain
     * @return $this
     */
    public function setDomain(string $domain): self
    {
        $this->domain = $domain;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getDomain(): ?string
    {
        return $this->domain;
    }

    /**
     * @param string $registration_event
     * @return $this
     */
    public function setRegistrationEvent(string $registration_event): self
    {
        $this->registration_event = $registration_event;
        return $this;
    }


    /**
     * @return string|null
     */
    public function getRegistrationEvent(): ?string
    {
        return $this->registration_event;
    }

    /**
     * @param string $viewing_event
     * @return $this
     */
    public function setViewingEvent(string $viewing_event): self
    {
        $this->viewing_event = $viewing_event;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getViewingEvent(): ?string
    {
        return $this->viewing_event;
    }

    /**
     * @param string $pixel_id
     * @return $this
     */
    public function setPixelId(string $pixel_id): self
    {
        $this->pixel_id = $pixel_id;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getPixelId(): ?string
    {
        return $this->pixel_id;
    }

    /**
     * @param string $type_of_service
     * @return $this
     */
    public function setTypeOfService(string $type_of_service): self
    {
        $this->type_of_service = $type_of_service;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getTypeOfService(): ?string
    {
        return $this->type_of_service;
    }


    /**
     * @return DateTimeInterface|null
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * @return DateTimeInterface|null
     */
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }



}
