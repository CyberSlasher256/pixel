<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Security\Core\User\UserInterface;
use DateTimeInterface;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

/**
 * @ORM\Entity(repositoryClass="App\Repository\PixelLogsRepository")
 * @ORM\Table(name="pixel_logs")
 * @ORM\HasLifecycleCallbacks
 */
class PixelLogs
{

    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="text", length=70, nullable=true)
     */
    private $domain;

    /**
     * @ORM\Column(type="text", length=1000, nullable=true)
     */
    private $user_id_in_crm;

    /**
     * @ORM\Column(type="string", length=70, nullable=true)
     */
    private $user_ip;

    /**
     * @ORM\Column(type="string", length=70, nullable=true)
     */
    private $mpc_4;

    /**
     * @ORM\Column(type="string", length=500, nullable=true)
     */
    private $http_user_agent;

    /**
     * @ORM\Column(type="string", length=10, nullable=true)
     */
    private $page_type;

    /**
     * @ORM\Column(type="datetime")
     */
    protected $created_at;

    /**
     * @ORM\PrePersist
     */
    public function onPrePersist()
    {
        $this->created_at = new \DateTime("now");
    }

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @param string $domain
     * @return $this
     */
    public function setDomain(string $domain): self
    {
        $this->domain = $domain;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getDomain(): ?string
    {
        return $this->domain;
    }

    /**
     * @param string $user_id_in_crm
     * @return $this
     */
    public function setUserIdInCrm(string $user_id_in_crm): self
    {
        $this->user_id_in_crm = $user_id_in_crm;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getUserIdInCrm(): ?string
    {
        return $this->user_id_in_crm;
    }


    /**
     * @param string $user_ip
     * @return $this
     */
    public function setUserIp(string $user_ip): self
    {
        $this->user_ip = $user_ip;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getUserIp(): ?string
    {
        return $this->user_ip;
    }

    /**
     * @param string $mpc_4
     * @return $this
     */
    public function setMpc4(string $mpc_4): self
    {
        $this->mpc_4 = $mpc_4;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getMpc4(): ?string
    {
        return $this->mpc_4;
    }

    /**
     * @param string $http_user_agent
     * @return $this
     */
    public function setHttpUserAgent(string $http_user_agent): self
    {
        $this->http_user_agent = $http_user_agent;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getHttpUserAgent(): ?string
    {
        return $this->http_user_agent;
    }

    /**
     * @param string $page_type
     * @return $this
     */
    public function setPageType(string $page_type): self
    {
        $this->page_type = $page_type;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getPageType(): ?string
    {
        return $this->page_type;
    }

    /**
     * @return DateTimeInterface|null
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }


}
